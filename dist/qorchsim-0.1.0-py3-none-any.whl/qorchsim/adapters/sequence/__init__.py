"""Narrow SeQUeNCe integration boundary."""
